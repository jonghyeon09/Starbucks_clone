$(document).ready(function () {
  const gnb_sub = document.querySelectorAll(".m_gnb_sub");
  const sub_ul = document.querySelectorAll(".m_gnb_sub>ul");
  const sub_up = document.querySelectorAll(".arrow_up");
  const sub_arrow = document.querySelectorAll(".arrow_sub");
  const m_gnb_title = document.querySelectorAll(".m_gnb_title > a");
  let count = false;
  let i;

  $(gnb_sub).hide();
  $(sub_ul).hide();
  $(sub_up).css({ transform: "rotate(0.5turn)" });
  $(sub_arrow).css({ transform: "rotate(0.5turn)" });
  console.log(m_gnb_title);
  $(m_gnb_title).click(function () {
    i = $(this).index();
    console.log($(m_gnb_title).index());
    if (count == false) {
      sub_menu_down(i);
      count = true;
    } else if (count == true) {
      sub_menu_up(i);
      count = false;
    }
  });

  function sub_menu_down(i) {
    $(gnb_sub).stop().slideDown();
    $(sub_up[i]).css({ transform: "none" });
  }
  function sub_menu_up(i) {
    $(gnb_sub).stop().slideUp();
    $(sub_up[i]).css({ transform: "rotate(0.5turn)" });
  }
});
