$(document).ready(function () {
  setTimeout(() => {
    document.querySelector(".main_slogan").style.opacity = "1";
  }, 500);
  setTimeout(() => {
    document.querySelector(".main_img01").style.opacity = "1";
  }, 1000);
  setTimeout(() => {
    document.querySelector(".main_img02").style.opacity = "1";
  }, 1500);
  setTimeout(() => {
    document.querySelector(".main_img03").style.opacity = "1";
  }, 2000);
  setTimeout(() => {
    document.querySelector(".slogan_bt").style.opacity = "1";
  }, 2500);
});
